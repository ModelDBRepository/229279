#ifndef NULLArgv_H
#define NULLArgv_H

char **NULLArgv();

#endif
