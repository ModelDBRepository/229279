/*
** $Id: copyright.h,v 1.1.1.1 2005/06/14 04:38:34 svitak Exp $
** $Log: copyright.h,v $
** Revision 1.1.1.1  2005/06/14 04:38:34  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.1  1992/12/11 19:05:38  dhb
** Initial revision
**
*/

/*
*******************************************************************
**                                                               **
**                            G E N E S I S                      **
**                 General Network Simulation Software           **
**                                                               **
**                             Source Code                       **
**                                                               **
**                  Copyright 1988 by Matt Wilson                **
**                              and the                          **
**    California Institute of Technology, Pasadena California.   **
**                        All rights reserved.                   **
**                                                               **
** Permission is given to use or modify this code                **
** provided that the above copyright notice is included.         **
** The author and the California Institute of Technology         **
** disclaim any warranty, expressed or implied, concerning       ** 
** the fitness of this software and will not be held liable      **
** for any damages or losses resulting from its use.             **
**                                                               **
*******************************************************************
*/

