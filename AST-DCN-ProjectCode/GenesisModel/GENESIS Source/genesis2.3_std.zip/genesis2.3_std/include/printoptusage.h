#ifndef _PRINTOPTUSAGE_H_
#define _PRINTOPTUSAGE_H_

extern void     printoptusage();	

#endif
