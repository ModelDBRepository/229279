/*
** $Id: seg_ext.h,v 1.1.1.1 2005/06/14 04:38:28 svitak Exp $
** $Log: seg_ext.h,v $
** Revision 1.1.1.1  2005/06/14 04:38:28  svitak
** Import from snapshot of CalTech CVS tree of June 8, 2005
**
** Revision 1.2  2001/04/25 17:16:59  mhucka
** Misc. small changes to improve portability and address compiler warnings.
**
** Revision 1.1  1992/12/11 19:04:15  dhb
** Initial revision
**
*/

#include "sim_ext.h"
#include "shell_func_ext.h"
#include "seg_defs.h"
#include "seg_struct.h"

extern	float rangauss();


