#include "sim_ext.h"
#include "shell_func_ext.h"
#include "simconn_struct.h"

extern Connection *GetConnection();
extern Connection *AddConnection();
